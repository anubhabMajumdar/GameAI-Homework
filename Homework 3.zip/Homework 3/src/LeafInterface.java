/**
 * Created by anubhabmajumdar on 4/5/17.
 */
public interface LeafInterface {
    public void evaluateLeaf(SteeringClass steeringClass);


}
