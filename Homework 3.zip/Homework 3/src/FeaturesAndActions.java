import java.util.ArrayList;

/**
 * Created by anubhabmajumdar on 4/19/17.
 */
public class FeaturesAndActions {
    ArrayList<String[]> filteredFeatures;
    ArrayList<String[]> filteredActions;

    public FeaturesAndActions(ArrayList<String[]> filteredFeatures, ArrayList<String[]> filteredActions) {
        this.filteredFeatures = filteredFeatures;
        this.filteredActions = filteredActions;
    }
}
