/**
 * Created by anubhabmajumdar on 4/4/17.
 */
public interface NodeInterface {

    public boolean evaluate(SteeringClass steeringClass);
}
