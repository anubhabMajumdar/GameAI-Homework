# CSC 584 : Homework 3

Use eclipse or Intellij to run the programs. Processing library has been added to the folder.

1. Decision Tree

Run DriverClassDT.java to see the Decision tree in action. The decision tree used is coded in makeTree() method in DecisionTree.java.
Video - https://youtu.be/l7y9ZwMPyEI

2. Behavior Tree

Run DriverClassDT_BT.java to see the Behavior tree in action. The Behavior tree used is coded in makeTree() method in BehaviourTree.java.
Video - https://youtu.be/plYTG3KJh9w

3. Learned Decision Tree

Run DriverClassLearnedTree.java to see the learned decision tree in action. The decision tree used is coded in makeLearnedTree() method in DecisionTree.java.
Video - https://youtu.be/YxytHHU-fl8

4. Writeup

The writeup file is named hw3_amajumd.pdf.

Environment is designed by me. Character images are taken from internet. 
References:
---------------------------------------
[1] “Lego superman.” Accessed on : 04/17/2017; https://lc-www-live-s.legocdn.com/r/www/r/catalogs/-/media/catalogs/characters/dc/fullsize/2014/76040-superman_360w_2x.png?l.r2=-2079447138.

[2] “Red monster.” Accessed on : 04/17/2017; http://fsb.zedge.net/scale.php?img=MS83LzIvNS8xLTEwMTM5MDgwLTE3MjUxMzMuanBn&ctype=1&v=4&q=71&xs=300&ys=266&sig=f646cac1f807dad3d23cb9133120724f950c0178.

[3] “Blue monster.” Accessed on : 04/17/2017; https://s-media-cache-ak0.pinimg.com/736x/b2/53/36/b25336fe10b2e2fbb709889f9b3e74c1.jpg.
